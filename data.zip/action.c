Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_cookie("guid=174B652F58BB1FE3X1488658403; DOMAIN=www.tns-counter.ru");

	lr_think_time(4);

	web_url("tmsec=yandex_mail", 
		"URL=https://www.tns-counter.ru/V13a****yandex_ru/ru/CP1251/tmsec=yandex_mail/?0.6879483977084792", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t167.inf", 
		LAST);

	lr_think_time(4);

	lr_start_transaction("LOG IN");

	web_submit_data("10102198_4", 
		"Action=https://mc.yandex.ru/watch/10102198?page-url=https%3A%2F%2Fmail.yandex.ru%2F&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1536x745%3Az%3A180%3Ai%3A20170310153622%3Aet%3A1489149382%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Aar%3A1%3Anb%3A1%3Acl%3A66%3Als%3A762358474662%3Arqn%3A9%3Arn%3A1048777849%3Ahid%3A672005724%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C10427%2C10427%2C86%2C%3Arqnl%3A1%3Ast%3A1489149382%3Au%3A1488658405454999924", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t168.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		EXTRARES, 
		"Url=../clmap/10102198?page-url=https%3A%2F%2Fmail.yandex.ru%2F&pointer-click=rn%3A64969379%3Ax%3A52152%3Ay%3A44712%3At%3A159%3Ap%3APWsAFAAA&browser-info=rqnl%3A1%3Ast%3A1489149383%3Au%3A1488658405454999924", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://mail.yandex.ru/neo2/favicon.ico", "Referer=", ENDITEM, 
		"Url=../clmap/10102198?page-url=https%3A%2F%2Fmail.yandex.ru%2F&pointer-click=rn%3A911478442%3Ax%3A49509%3Ay%3A42082%3At%3A173%3Ap%3APWsA1FAAA&browser-info=rqnl%3A1%3Ast%3A1489149384%3Au%3A1488658405454999924", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=../clmap/10102198?page-url=https%3A%2F%2Fmail.yandex.ru%2F&pointer-click=rn%3A924345444%3Ax%3A48628%3Ay%3A-877%3At%3A237%3Ap%3APWsAFAAA&browser-info=rqnl%3A1%3Ast%3A1489149391%3Au%3A1488658405454999924", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=../clmap/10102198?page-url=https%3A%2F%2Fmail.yandex.ru%2F&pointer-click=rn%3A363341869%3Ax%3A48628%3Ay%3A-877%3At%3A248%3Ap%3APWsAFAAA&browser-info=rqnl%3A1%3Ast%3A1489149392%3Au%3A1488658405454999924", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=../clmap/10102198?page-url=https%3A%2F%2Fmail.yandex.ru%2F&pointer-click=rn%3A575200575%3Ax%3A48628%3Ay%3A-877%3At%3A278%3Ap%3APWsAFAAA&browser-info=rqnl%3A1%3Ast%3A1489149395%3Au%3A1488658405454999924", "Referer=https://mail.yandex.ru/", ENDITEM, 
		LAST);

	web_add_cookie("display-culture=en-US; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20170304; DOMAIN=iecvlist.microsoft.com");

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE11/1426178821/iecompatviewlist.xml", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t169.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://mc.yandex.ru/clmap/10102198?page-url=https%3A%2F%2Fmail.yandex.ru%2F&pointer-click=rn%3A886418071%3Ax%3A28774%3Ay%3A41368%3At%3A417%3Ap%3A%3FWA3FAAA&browser-info=rqnl%3A1%3Ast%3A1489149409%3Au%3A1488658405454999924", "Referer=https://mail.yandex.ru/", ENDITEM, 
		LAST);

	web_custom_request("10102198_5", 
		"URL=https://mc.yandex.ru/watch/10102198?page-url=https%3A%2F%2Fmail.yandex.ru%2F&ut=noindex&browser-info=j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310153648%3Aet%3A1489149409%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Aar%3A1%3Apa%3A1%3Als%3A762358474662%3Arqn%3A10%3Arn%3A101309098%3Ahid%3A672005724%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149409%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t170.inf", 
		"Body=site-info=%7B%22%D0%9F%D1%80%D0%BE%D0%BC%D0%BE-%D1%85%D0%BE%D1%81%D1%82%D1%80%D1%83%D1%82%20%D1%81%20%D0%BC%D0%BE%D0%B1%D0%B8%D0%BB%D1%8C%D0%BD%D1%8B%D0%BC%20%D0%BF%D1%80%D0%B8%D0%BB%D0%BE%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5%D0%BC%2C%20%D0%B5%D1%81%D1%82%D1%8C%20L-%D0%BA%D1%83%D0%BA%D0%B0%22%3A%7B%22RU%22%3A%7B%22%D0%A2%D1%91%D0%BC%D0%BD%D1%8B%D0%B9%22%3A%7B%22%D0%94%D0%BD%D1%91%D0%BC%20(%D0%98%D0%BD%D0%B2%D0%B5%D1%80%D1%81%D0%B8%D1%8F)"
		"%22%3A%22%D0%9A%D0%BB%D0%B8%D0%BA%D0%B8%20%D0%BD%D0%B0%20'%D0%92%D0%BE%D0%B9%D1%82%D0%B8'%22%7D%7D%7D%7D", 
		LAST);

	web_add_cookie("yandexuid=1323753751488658402; DOMAIN=passport.yandex.ru");

	web_add_cookie("i=9watCZ0XndZ9hI+MrL2gQmQkLUJywAC+B5aUe+iWdudktzdxuU4qK7ZNkxGsKlZxvKPmmudu+V+Ei9RoDPcxI3SXk0w=; DOMAIN=passport.yandex.ru");

	web_add_cookie("_ym_uid=1488658405454999924; DOMAIN=passport.yandex.ru");

	web_add_cookie("_ym_isad=2; DOMAIN=passport.yandex.ru");

	web_add_cookie("fuid01=58bb1fe43f1985ca.mchv1kTx9TEts0-0Gp_WmXaQDv9YzfRxHMjAhTjj3FWSUQEJC61ZkwpNsdz8bUlcpKF_3mbcsWNVPeDp-t2gp4jJPGbGmhsyD7VuFZi-GicCHCUYXGlhUGmo6Ch_ljdX; DOMAIN=passport.yandex.ru");

	web_add_cookie("L=CV5nAFpcYURzVWsGZFlvX18CZgVhegZLQjccfio1BAN4eXs=.1489141986.13001.388127.665a1afc4097caf3bc587d01b76f3b8d; DOMAIN=passport.yandex.ru");

	web_add_cookie("yandex_gid=213; DOMAIN=passport.yandex.ru");

	web_add_cookie("lah=M3dfMX6w8vOmYkLW1uGcak83.1489149247.13001.1.0cdd55af8bb172e442225fd9361f21eb; DOMAIN=passport.yandex.ru");

	web_submit_data("passport", 
		"Action=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t171.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=retpath", "Value=https://mail.yandex.ru", ENDITEM, 
		"Name=timestamp", "Value=1489149408815", ENDITEM, 
		"Name=login", "Value=ufo.xco2017@yandex.ru", ENDITEM, 
		"Name=passwd", "Value=QWERTY1210409", ENDITEM, 
		"Name=twoweeks", "Value=yes", ENDITEM, 
		EXTRARES, 
		"Url=https://mc.yandex.ru/metrika/watch.js?_=1489149414651", "Referer=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", ENDITEM, 
		LAST);

	web_submit_data("784657", 
		"Action=https://mc.yandex.ru/webvisor/784657?rn=541676534&page-url=https%3A%2F%2Fpassport.yandex.ru%2Fpassport%3Fmode%3Dauth%26retpath%3Dhttps%253A%252F%252Fmail.yandex.ru%252Flite%252Finbox&wmode=0&wv-type=0&wv-hit=423266587&wv-part=1&wv-check=36427&browser-info=v%3A785%3Az%3A180%3Ai%3A20170310131146%3Arqnl%3A1%3Ast%3A1489149415%3Au%3A1488658405454999924", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", 
		"Snapshot=t172.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=wv-data", "Value="
		"AQFkACsAAIAM6QUEAG4AYgAtADECKFgBAk0BDVgMAAEDRQIaCAjwC*oBRxcCoAUBBEUDGggI8AvFAeJiAuspAQVJBBoC4mIC-vIBBk0FGuJiAhY6AQdJBhoB4mICQSQBCEUHIAgI8AuyAeB3AAEJRQgaCAjwCyeYUAJJ4AEKZAkvCAiZARUFAGwAbwBnAGkAbgLpYAcKAAAFbG9naW4AAQtBCBoBCDDwC03T0wJJ4AEMZAsvCDCSARYGAHAAYQBzAHMAdwBkAtyHBwwAAgZwYXNzd2QAAQ1BCBoDCH3wCyt0IAKc9AEORQ0aCH3wCxcQ1wLZKgEPRQ4PCH07FxDXAuNmARBVDTMIlgGVARJOxGQHArbzARFFEC8MlwENDQAAAuhLBxEABAh0d293ZWVrcwABEkEIGgQIqAHwCxIAAAIYrgETRRIPCK8BFggAAAKxLwEUQRIPAR6vARYIAAACmL8BFUESDwI0rwEWCAAAAru5ARZBEg8DSq"
		"8BFggAAAKvCgEXQRIPBGCvARYIAAACnhUBGEESDwV2rwEWCAAAAqrFARlECC8AAAAAAvr*BD8KchABIEEKchABBJScAQyGAREBBJ2cAQyIAREBBKScAQyIAREBBIedAQ8oDwEgiZ0BDygPAQ__", ENDITEM, 
		EXTRARES, 
		"Url=../watch/784657?wmode=5&callback=_ymjsp1003179171&page-ref=https%3A%2F%2Fmail.yandex.ru%2F&page-url=https%3A%2F%2Fpassport.yandex.ru%2Fpassport%3Fmode%3Dauth%26from%3Dmail%26origin%3Dhostroot_ru_l_mobile_enter%26retpath%3Dhttps%253A%252F%252Fmail.yandex.ru&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1536x745%3Az%3A180%3Ai%3A20170310153654%3Aet%3A1489149415%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Apv%3A1%3Als%3A155092419075%3Arqn%3A19%3Arn%3A828284798%3Ahid%3A596230488%3Ads%3A0%2C1189%2C1018%2C4%2C31%2C0%2C%2C2227%2C16%2C5921%2C5921%2C0%2C5881%3Afp%3A4733%3Awn%3A26790%3Ahl%3A2%3Arqnl%3A1%3Ast%3A1489149415%3Au%3A1488658405454999924%3At%3A%D0%90%D0%B2%D1%82%D0%BE%D1%80%D0%B8%D0%B7%D0%"
		"B0%D1%86%D0%B8%D1%8F", "Referer=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", ENDITEM, 
		LAST);

	web_custom_request("784657_2", 
		"URL=https://mc.yandex.ru/watch/784657?page-url=https%3A%2F%2Fpassport.yandex.ru%2Fpassport%3Fmode%3Dauth%26from%3Dmail%26origin%3Dhostroot_ru_l_mobile_enter%26retpath%3Dhttps%253A%252F%252Fmail.yandex.ru&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310153655%3Aet%3A1489149415%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A155092419075%3Arqn%3A20%3Arn%3A142861885%3Ahid%3A596230488%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149415%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", 
		"Snapshot=t173.inf", 
		"Body=site-info=%7B%22%D0%A1%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0%20%D0%B0%D0%B2%D1%82%D0%BE%D1%80%D0%B8%D0%B7%D0%B0%D1%86%D0%B8%D0%B8%22%3A%7B%22hostroot_ru_l_mobile_enter%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%20%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D1%8B%22%7D%7D", 
		LAST);

	web_add_cookie("_ym_visorc_784657=w; DOMAIN=mc.yandex.ru");

	web_submit_data("784657_3", 
		"Action=https://mc.yandex.ru/webvisor/784657?rn=739978116&page-url=https%3A%2F%2Fpassport.yandex.ru%2Fpassport%3Fmode%3Dauth%26from%3Dmail%26origin%3Dhostroot_ru_l_mobile_enter%26retpath%3Dhttps%253A%252F%252Fmail.yandex.ru&wmode=0&wv-type=0&wv-hit=596230488&wv-part=1&wv-check=51861&browser-info=v%3A785%3Az%3A180%3Ai%3A20170310153654%3Arqnl%3A1%3Ast%3A1489149415%3Au%3A1488658405454999924", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", 
		"Snapshot=t174.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=wv-data", "Value="
		"HACADOkFgAzpBQ8DDgMBAWQAKwAAgAzpBQQAbgBiAC0AMQIoWAECTQENDzgAAQNFAhoAAIAM6AX9nAKgBQEERQMaAACADLQFmewC6ykBBUEEGgLqBNcBrALWAuJiAv7yAQZFBRrqBIkCrAKkAuJiAhY6AQdJBhoB4mICQSQBCEUHIP8ExQKCArAB4HcAAQlFCBr-BMUCggIpmFACSeABCmQJL-8ExQKCAh8FAGwAbwBnAGkAbgLpYAcKAAAFbG9naW4AAQtBCBoB-wTvAoICKdPTAkngAQxkCy--BO8CggIfBgBwAGEAcwBzAHcAZALchwcMAAIGcGFzc3dkAAENQQgaA-8EmQOCAkR0IAKc9AEORQ0a-wSZA4ICIBDXAtkqAQ9FDg--BJkD2gEgENcC42YBEFUNM-8EwwORARBOxGQHArbzARFFEC*DBcYDDQ0AAALoSwcRAAQIdHdvd2Vla3MAARJBCBoE-wTeA4ICGAAAAhiuARNFEg"
		"*jBd4DGBgAAAKxLwEUQRIPAcIF3gMYGAAAApi-ARVBEg8C4QXeAxgYAAACu7kBFkESDwOABt4DGBgAAAKvCgEXQRIPBJ8G3gMYGAAAAp4VARhBEg8FvgbeAxgYAAACqsUBGUQILwAAAAAC*v4BGmAILwEAAAAABQBzAHQAYQB0AGUCI4UBG2AILwIAAAAACAB0AHIAYQBjAGsAXwBpAGQCRAERAwoCBgTuCU8CCATvCU0CCAToCUgBHEUEGgAAgAxGAAACsOQBHU0cGgAAAhYJAgkd2QlF", ENDITEM, 
		LAST);

	web_url("784657_7", 
		"URL=https://mc.yandex.ru/clmap/784657?page-url=https%3A%2F%2Fpassport.yandex.ru%2Fpassport%3Fmode%3Dauth%26from%3Dmail%26origin%3Dhostroot_ru_l_mobile_enter%26retpath%3Dhttps%253A%252F%252Fmail.yandex.ru&pointer-click=rn%3A134763003%3Ax%3A46123%3Ay%3A35634%3At%3A101%3Ap%3A%3FAA3FA1AA2AA&browser-info=rqnl%3A1%3Ast%3A1489149425%3Au%3A1488658405454999924", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", 
		"Snapshot=t178.inf", 
		LAST);

	web_custom_request("784657_8", 
		"URL=https://mc.yandex.ru/watch/784657?page-url=https%3A%2F%2Fpassport.yandex.ru%2Fpassport%3Fmode%3Dauth%26from%3Dmail%26origin%3Dhostroot_ru_l_mobile_enter%26retpath%3Dhttps%253A%252F%252Fmail.yandex.ru&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310153704%3Aet%3A1489149425%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A155092419075%3Arqn%3A22%3Arn%3A220193026%3Ahid%3A596230488%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149425%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", 
		"Snapshot=t179.inf", 
		"Body=site-info=%7B%22%D0%A1%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0%20%D0%B0%D0%B2%D1%82%D0%BE%D1%80%D0%B8%D0%B7%D0%B0%D1%86%D0%B8%D0%B8%22%3A%7B%22hostroot_ru_l_mobile_enter%22%3A%22%D0%9A%D0%BB%D0%B8%D0%BA%20%D0%BD%D0%B0%20%D0%BA%D0%BD%D0%BE%D0%BF%D0%BA%D1%83%20%D0%92%D0%BE%D0%B9%D1%82%D0%B8%22%7D%7D", 
		LAST);

	web_submit_data("784657_9", 
		"Action=https://mc.yandex.ru/webvisor/784657?rn=289218354&page-url=https%3A%2F%2Fpassport.yandex.ru%2Fpassport%3Fmode%3Dauth%26from%3Dmail%26origin%3Dhostroot_ru_l_mobile_enter%26retpath%3Dhttps%253A%252F%252Fmail.yandex.ru&wmode=0&wv-type=0&wv-hit=596230488&wv-part=3&wv-check=36324&browser-info=v%3A785%3Az%3A180%3Ai%3A20170310153654%3Arqnl%3A1%3Ast%3A1489149425%3Au%3A1488658405454999924", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", 
		"Snapshot=t180.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=wv-data", "Value=D7cBErcBDAK5AQTVCEwBJVUgGqcDZrEFED*MP4wCoWkCugElqQUJAroBH*kFSAK6AQS9CLkBAroBBKQI5QECuwEEjQiAAgK7AQT4B5oCArsBBOcHtAICvAEE2AfMAgK8AQTEB*QCArwBBLQH*AICvQEEoweGAwK9AQenAogBAr0BB5YCkwECvgEkFg4CvgEkBBUCvgEPzQEaAr8BD8MBGgK-AQ*-ARoCwAEPuAEaAsEBD7QBFwLBAQ*zARACwgEPqwEHAsMBD6cBBgLEAQ*jAQgCxQEPnwELAsUBD5wBDwTIAQ*ZAREBDsgBEcgBDA-IARLIAQwOyAERyAEPHskBD5kBEQEgyQEPmQERAQvJAQACCgw_", ENDITEM, 
		LAST);

	web_custom_request("784657_10", 
		"URL=https://mc.yandex.ru/watch/784657?page-url=https%3A%2F%2Fpassport.yandex.ru%2Fpassport%3Fmode%3Dauth%26from%3Dmail%26origin%3Dhostroot_ru_l_mobile_enter%26retpath%3Dhttps%253A%252F%252Fmail.yandex.ru&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310153704%3Aet%3A1489149425%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A155092419075%3Arqn%3A23%3Arn%3A458548755%3Ahid%3A596230488%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149425%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", 
		"Snapshot=t181.inf", 
		"Body=site-info=%7B%22%D0%A1%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0%20%D0%B0%D0%B2%D1%82%D0%BE%D1%80%D0%B8%D0%B7%D0%B0%D1%86%D0%B8%D0%B8%22%3A%7B%22hostroot_ru_l_mobile_enter%22%3A%22%D0%9E%D1%82%D0%BF%D1%80%D0%B0%D0%B2%D0%BA%D0%B0%20%D1%84%D0%BE%D1%80%D0%BC%D1%8B%20%D0%B0%D0%B2%D1%82%D0%BE%D1%80%D0%B8%D0%B7%D0%B0%D1%86%D0%B8%D0%B8%22%7D%7D", 
		LAST);

	web_submit_data("784657_11", 
		"Action=https://mc.yandex.ru/webvisor/784657?rn=91850524&page-url=https%3A%2F%2Fpassport.yandex.ru%2Fpassport%3Fmode%3Dauth%26from%3Dmail%26origin%3Dhostroot_ru_l_mobile_enter%26retpath%3Dhttps%253A%252F%252Fmail.yandex.ru&wmode=0&wv-type=0&wv-hit=596230488&wv-part=4&wv-check=3341&browser-info=v%3A785%3Az%3A180%3Ai%3A20170310153654%3Arqnl%3A1%3Ast%3A1489149425%3Au%3A1488658405454999924", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", 
		"Snapshot=t182.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=wv-data", "Value=DQ__", ENDITEM, 
		EXTRARES, 
		"Url=https://yastatic.net/morda-logo/i/favicon_islands.ico", "Referer=", ENDITEM, 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_cookie("_ym_visorc_784657=w; DOMAIN=mail.yandex.ru");

	web_add_cookie("pref=1; DOMAIN=mail.yandex.ru");

	web_submit_data("passport_2", 
		"Action=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://passport.yandex.ru/passport?mode=auth&from=mail&origin=hostroot_ru_l_mobile_enter&retpath=https%3A%2F%2Fmail.yandex.ru", 
		"Snapshot=t183.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value=ufo.xco2017@yandex.ru", ENDITEM, 
		"Name=passwd", "Value=qwerty1210409", ENDITEM, 
		"Name=retpath", "Value=https://mail.yandex.ru", ENDITEM, 
		"Name=state", "Value=submit", ENDITEM, 
		"Name=track_id", "Value=ff6c7e298a8c4733eca13e1d62dd90b84a", ENDITEM, 
		EXTRARES, 
		"Url=https://yastatic.net/jquery/1.11.0/jquery.min.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/3eb2e1cc41460d95995f834428a9acd8.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/ba7e9badabc98c5ae3cca784db524814.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/af3e1e6b81ddd716587a21e4fc576760.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/4e4809856dd1f503dda6ba94423bad55.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/05b0aa7fc5117bd0d70cc56c2ef3157f.css", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/122bafe8ab81f6c5cfe8221ca490c361.css", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/2d8f9186f14ffd5f1e499ed44caf5a1d.css", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/cddfafadf246078e0f92f7b665e15bd6.css", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://www.tns-counter.ru/V13a****yandex_ru/ru/CP1251/tmsec=yandex_mail/0", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/cc99f387b317b1a8078e164f2817462d.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/dc5f5eaae6ec5f7f1454229e170d9697.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/252fbe22b3b120d3c764c02627fc7f05.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/01212c333513b029a6961f84114a53a6.css", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/16a6d8f13263ec8945a14774d8a55a05.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/3df1321be71a6c1b1cbaab06850c68f8.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/e2dbdca7f5fcd1cb63bd858028547630.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/d682df1f0923dfdc911273f0ad7d9c4b.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/e627b8da01e01bd7647173528f0ca9b3.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/37eb30e9afb68eaa759208f1a6e1470a.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/9e2cbfb5cd384b63a2e38718cd217b01.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/dda3f2a371c171ba39346f4f99036649.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/b27dcb0815160c6be844843dd01ddf5a.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/b7ab82efff1d65d173060fa8b6ba8a10.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/12ab231a6bdd3272c73262b228d2b211.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://mc.yandex.ru/metrika/watch.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://mc.yandex.ru/watch/40081755?wmode=5&callback=_ymjsp361358266&page-ref=https%3A%2F%2Fpassport.yandex.ru%2Fpassport%3Fmode%3Dauth%26from%3Dmail%26origin%3Dhostroot_ru_l_mobile_enter%26retpath%3Dhttps%253A%252F%252Fmail.yandex.ru&page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1519x745%3Az%3A180%3Ai%3A20170310153709%3Aet%3A1489149430%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Apv%3A1%3Als%3A1153974744958%3Arqn%3A53%3Arn%3A476004607%3Ahid%3A242914354%3Ads%3A0%2C0%2C164%2C566%2C3558%2C0%2C%2C164%2C0%2C3979%2C3980%2C0%2C3955%3Afp%3A3982%3Arqnl%3A1%3Ast%3A1489149430%3Au%3A1488658405454999924%3At%3A%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81.%D0%9F%D0%BE%D1%87%D1%82%D0%B0", "Referer="
		"https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/FOhHIssLFPx0QqXY9ZyqFHTBaIE.gif", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/aa15bRU_q6CoaClAAXU30jTI2R4.gif", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/E5axKlv9j2MvIGHrlTIOBJO9LHs.gif", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/lVCP1HwuzWTozmjWaas1Govbdpw.gif", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/N8TqB6Xn1FnD_lrrQqBbwB1lkI0.gif", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/vFhWcwbqbozYzd_hUpysx_-4kPs.gif", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/QH9l_KzKNMxmSxRhAz1w1fZ8W1M.gif", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/esPrIWqs1JEdi7k41PWvIUeYWLw.gif", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/p7vfW6tT5FxXKzQJr5fHFjr8_ls.gif", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/ftG_g5PBLY3vNpbeycqToQ3F5y8.gif", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/ve196YKlcLJiZ0CECrlNXgKPGSc.gif", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://mail.yandex.ru/monitoring_liza.txt?uid=474076123&cid=u2709-1489149426954-81932979&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%23inbox&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58&node=false&lifetime=0&allTime=392&allSumTime=241&requestTime=150&selfTime=242&full=392&collectModels.0=22&requestModels.0=150&collectViews=3&generateHTML=35&html2node=12&triggerHideEvents=1&insertNodes=28&triggerEvents=140&blockname="
		"messages&request=150&event=BlockTimings&visibilityState=visible&show=392&browser=MSIE", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/monograms/monograms/v2//double/XU.png", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/dac9tFEbu9cex_YLUfbDCvKjBsw.png", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/1ed3054ead5812306c0fef1682c81e30.css", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/f37866c71eb5634821094a2db06c41eb.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/ebff739f4b3ed40956424881f1a216dd.css", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/4f115d083a2167f4334a84d88823fc5d.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://mail.yandex.ru/monitoring_liza.txt?uid=474076123&cid=u2709-1489149426954-81932979&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%23inbox&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58&node=false&lifetime=1&event=prefetch&theme=colorful&locale=ru", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://mail.yandex.ru/monitoring_liza.txt?uid=474076123&cid=u2709-1489149426954-81932979&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58&node=false&lifetime=1&event=LoadingTime&inline-icons=true&handlers=0.1750&prepare=0.0440&static-load=0.3820&static-run=0.3360&parse-prefetch=0.0080&pageinit=0.0220&first-draw=0.7650&trigger-init="
		"0.1430&regionId=213&theme=colorful&isRegToday=false&timeout=1.8480&tm.connectEnd=1489149428515&tm.connectStart=1489149428515&tm.domComplete=1489149428936&tm.domContentLoadedEventEnd=1489149428912&tm.domContentLoadedEventStart=1489149428912&tm.domInteractive=1489149428912&tm.domLoading=1489149428748&tm.domainLookupEnd=1489149428515&tm.domainLookupStart=1489149428515&tm.fetchStart=1489149428515&tm.loadEventEnd=1489149428937&tm.loadEventStart=1489149428937&tm.msFirstPaint=1489149428939&"
		"tm.navigationStart=1489149424957&tm.redirectEnd=0&tm.redirectStart=0&tm.requestStart=1489149428584&tm.responseEnd=1489149429314&tm.responseStart=1489149428748&tm.unloadEventEnd=0&tm.unloadEventStart=0&nav.redirectCount=0&nav.type=0&nav.TYPE_BACK_FORWARD=2&nav.TYPE_NAVIGATE=0&nav.TYPE_RELOAD=1&nav.TYPE_RESERVED=255&afterload=true", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/b414bafc4d2f9189a2b59f810a62c994.css", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/fcc50f5bc297b5060ca7d08f397b9ce0.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/aPAEQRS76xxVS8fZgl5wmBmvYNo.png", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/60953330d04a753bae16c21e2e7ca7d1.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/bcMRR38jHYU92Kos2tBWEEJdZcg.png", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/cXatqCo0KnZ3BOvwZ2Tdm4Fh7dk.png", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/u2709/12.10.51/static/sound/message.mp3", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews/49544/fe609477cc636d474668d8e2a897900c/50x50", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-yapic/0/0-0/islands-50", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews/61968/4ac264ede2ce4ca48aff37326fb4e5d7/50x50", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews/49450/c662f1f69b527fcad75288dcb2e50455/50x50", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-yapic/0/0-0/islands-retina-50", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://mail.yandex.ru/monitoring_liza.txt?uid=474076123&cid=u2709-1489149426954-81932979&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916593&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58&node=false&lifetime=31&allTime=72&allSumTime=45&requestTime=0&selfTime=72&full=72&collectModels.0=3&requestModels.0=0&collectViews=1&generateHTML=4&html2node=1&"
		"triggerHideEvents=0&insertNodes=11&triggerEvents=25&blockname=message-body&request=0&event=BlockTimings&visibilityState=visible&show=72&browser=MSIE&afterload=true", "Referer=https://mail.yandex.ru/", ENDITEM, 
		LAST);

	web_submit_data("models.jsx", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=labels,service-emails,get_user_activity,messages", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t184.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_timestamp", "Value=1489149428895", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		"Name=_model.0", "Value=labels", ENDITEM, 
		"Name=_model.1", "Value=service-emails", ENDITEM, 
		"Name=_model.2", "Value=get_user_activity", ENDITEM, 
		"Name=_model.3", "Value=messages", ENDITEM, 
		"Name=current_folder.3", "Value=1", ENDITEM, 
		"Name=with_pins.3", "Value=yes", ENDITEM, 
		"Name=threaded.3", "Value=yes", ENDITEM, 
		LAST);

	web_submit_data("40081755", 
		"Action=https://mc.yandex.ru/watch/40081755?page-ref=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%23inbox&page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1519x745%3Az%3A180%3Ai%3A20170310153709%3Aet%3A1489149430%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Apv%3A1%3Als%3A1153974744958%3Arqn%3A54%3Arn%3A196779840%3Ahid%3A242914354%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149430%3Au%3A1488658405454999924%3At%3A%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81.%D0%9F%D0%BE%D1%87%D1%82%D0%B0", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t185.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("models.jsx_2", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=collectors", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t186.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=collectors", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149430393", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_3", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=informer-news", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t187.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=informer-news", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149430398", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_4", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=filters", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t188.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=filters", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149430472", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_5", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=db-ro-status", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t189.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=db-ro-status", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149430470", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_custom_request("40081755_2", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310153710%3Aet%3A1489149431%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A55%3Arn%3A3065314%3Ahid%3A242914354%3Ads%3A%2C%2C%2C1886%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149431%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t190.inf", 
		"Body=site-info="
		"%5B%7B%22theme%22%3A%7B%22u2709%22%3A%7B%22%D0%BE%D0%B4%D0%BD%D0%B0%20%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0%22%3A%22colorful%22%7D%7D%7D%2C%7B%22%D0%97%D0%B0%D0%BB%D0%BE%D0%B3%D0%B8%D0%BD%D0%BE%D0%B2%D0%B0%D1%8F%20%D1%88%D0%B0%D0%BF%D0%BA%D0%B0.%D0%9B%D0%B5%D0%B2%D0%B0%D1%8F%20%D1%87%D0%B0%D1%81%D1%82%D1%8C%22%3A%7B%22%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB%D1%8C%D0%BD%D0%B0%D1%8F%20%D0%BD%D0%B0%D0%B2%D0%B8%D0%B3%D0%B0%D1%86%D0%B8%D1%8F%2F%D0%A1%D0%B5%D1%80%D0%B2%D0%B8%D1%81%D1%8B%22%3A%7B"
		"%22yandex.ru%22%3A%5B%7B%22%D0%9F%D0%BE%D0%B8%D1%81%D0%BA%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%22%7D%2C%7B%22%D0%9A%D0%BE%D0%BD%D1%82%D0%B0%D0%BA%D1%82%D1%8B%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%22%7D%2C%7B%22%D0%94%D0%B8%D1%81%D0%BA%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%22%7D%2C%7B%22%D0%94%D0%B5%D0%BD%D1%8C%D0%B3%D0%B8%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%22%7D%5D%7D%7D%7D%2C%7B%22stat%22%3A%7B%22eexp%22%3A%2236377%22%7D%7D%2C%7B%22stat%22%3A%7B%22eexp%22%3A%2240287%22%7D%7D%2C%7B%22stat%"
		"22%3A%7B%22eexp%22%3A%2238717%22%7D%7D%2C%7B%22stat%22%3A%7B%22eexp%22%3A%2234595%22%7D%7D%2C%7B%22stat%22%3A%7B%22eexp%22%3A%2231190%22%7D%7D%2C%7B%22stat%22%3A%7B%22puid%22%3A%22474076123%22%7D%7D%2C%7B%22%D0%9F%D1%80%D0%BE%D0%BC%D0%BE%20%D1%81%D0%B1%D0%BE%D1%80%D1%89%D0%B8%D0%BA%D0%BE%D0%B2%22%3A%7B%22%D0%9F%D1%80%D0%BE%D0%BC%D0%BE-%D0%BA%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0%20%C2%AB%D0%94%D0%BE%D0%B1%D0%B0%D0%B2%D0%B8%D1%82%D1%8C%20%D0%B2%D0%B0%D1%88%20%D1%8F%D1%89%D0%B8%D0%BA%C2%BB%22%3A%22%D0%9F%D0"
		"%BE%D0%BA%D0%B0%D0%B7%22%7D%7D%5D", 
		LAST);

	web_submit_data("models.jsx_6", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=do-mail-reset-recent-counter", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t191.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=do-mail-reset-recent-counter", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149430477", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_7", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=userphones", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t192.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=userphones", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149430473", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_8", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=messages-pager", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t193.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=messages-pager", ENDITEM, 
		"Name=current_folder.0", "Value=1", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149430402", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_9", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=messages-types", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t194.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=messages-types", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149430404", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_10", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=last-login", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t195.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=last-login", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149430407", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_11", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=social-avatars", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t196.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=_model.0", "Value=social-avatars", ENDITEM, 
		"Name=refs.0", "Value=6614159eec6fa7af7b4f667514d7a2c3:ufo.xco2017@yandex.ru", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149430425", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_12", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=user-dropdown-data", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t197.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=user-dropdown-data", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149431102", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	lr_end_transaction("LOG IN",LR_AUTO);

	web_add_cookie("yandexuid=1323753751488658402; DOMAIN=awaps.yandex.ru");

	web_add_cookie("i=9watCZ0XndZ9hI+MrL2gQmQkLUJywAC+B5aUe+iWdudktzdxuU4qK7ZNkxGsKlZxvKPmmudu+V+Ei9RoDPcxI3SXk0w=; DOMAIN=awaps.yandex.ru");

	web_add_cookie("_ym_uid=1488658405454999924; DOMAIN=awaps.yandex.ru");

	web_add_cookie("_ym_isad=2; DOMAIN=awaps.yandex.ru");

	web_add_cookie("fuid01=58bb1fe43f1985ca.mchv1kTx9TEts0-0Gp_WmXaQDv9YzfRxHMjAhTjj3FWSUQEJC61ZkwpNsdz8bUlcpKF_3mbcsWNVPeDp-t2gp4jJPGbGmhsyD7VuFZi-GicCHCUYXGlhUGmo6Ch_ljdX; DOMAIN=awaps.yandex.ru");

	web_add_cookie("yandex_gid=213; DOMAIN=awaps.yandex.ru");

	web_add_cookie("_ym_visorc_784657=w; DOMAIN=awaps.yandex.ru");

	web_url("001001.htm", 
		"URL=https://awaps.yandex.ru/0/9947/001001.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t198.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(5);

	lr_start_transaction("check messages");

	web_submit_data("40081755_3", 
		"Action=https://mc.yandex.ru/watch/40081755?page-ref=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%23inbox&page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916593&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1519x745%3Az%3A180%3Ai%3A20170310153740%3Aet%3A1489149460%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Apv%3A1%3Als%3A1153974744958%3Arqn%3A56%3Arn%3A931326681%3Ahid%3A242914354%3Ads%3A%2C%2C%2C2178%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149460%3Au%3A1488658405454999924%3At%3A1%20%C2%B7%20%D0%92%D1%85%D0%BE%D0%B4%D1%8F%D1%89%D0%B8%D0%B5%20%E2%80%94%20%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%"
		"D1%81.%D0%9F%D0%BE%D1%87%D1%82%D0%B0", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t199.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("models.jsx_13", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=message-body,message-nearest", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t200.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=message-body", ENDITEM, 
		"Name=ids.0", "Value=161566636631916593", ENDITEM, 
		"Name=is_spam.0", "Value=false", ENDITEM, 
		"Name=raw.0", "Value=false", ENDITEM, 
		"Name=draft.0", "Value=false", ENDITEM, 
		"Name=_model.1", "Value=message-nearest", ENDITEM, 
		"Name=ids.1", "Value=161566636631916593", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149460244", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("action-log.jsx", 
		"Action=https://mail.yandex.ru/u2709/api/action-log.jsx", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t201.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=data", "Value={\"timestamp\":1489138660490,\"action\":\"show\",\"platform\":\"Win32\",\"filter\":{\"page\":\"message\",\"type\":null,\"param\":null},\"message\":{\"thread\":0,\"timestamp\":1489149209000,\"type\":[4,54],\"from\":\"ufo.xco2017@yandex.ru\",\"index\":1,\"subject\":\"test\",\"folder\":{\"fid\":\"1\",\"symbol\":\"inbox\"},\"mid\":\"161566636631916593\"}}", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149460490", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_14", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=do-journal-log", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t202.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=do-journal-log", ENDITEM, 
		"Name=params.0", "Value={\"operation\":\"startReading\",\"target\":\"message\",\"isSearch\":false,\"readingId\":\"132375375148865840219a6ec7df13618\",\"mid\":\"161566636631916593\"}", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149460492", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_15", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=email-info", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t203.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=_model.0", "Value=email-info", ENDITEM, 
		"Name=email.0", "Value=ufo.xco2017@yandex.ru", ENDITEM, 
		"Name=ref.0", "Value=6614159eec6fa7af7b4f667514d7a2c3", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149460524", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_16", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=do-messages", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t204.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=do-messages", ENDITEM, 
		"Name=ids.0", "Value=161566636631916593", ENDITEM, 
		"Name=action.0", "Value=mark", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149460480", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_17", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=abook-contacts", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t205.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=_model.0", "Value=abook-contacts", ENDITEM, 
		"Name=emails.0", "Value=ufo.xco2017@yandex.ru", ENDITEM, 
		"Name=pagesize.0", "Value=30", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149460608", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_18", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=translate-langs", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t206.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=translate-langs", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149460629", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_custom_request("40081755_4", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916593&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310153741%3Aet%3A1489149462%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A57%3Arn%3A613979899%3Ahid%3A242914354%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149462%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t207.inf", 
		"Body=site-info="
		"%5B%7B%22%D0%9F%D1%80%D0%BE%D1%81%D0%BC%D0%BE%D1%82%D1%80%20%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%B0%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%20%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%B0%20%D0%BD%D0%B0%20%D0%BE%D1%82%D0%B4%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9%20%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B5%22%7D%2C%7B%22%D0%9F%D1%80%D0%B0%D0%B2%D0%B0%D1%8F%20%D0%BA%D0%BE%D0%BB%D0%BE%D0%BD%D0%BA%D0%B0%22%3A%7B%22%D0%A1%D1%82%D0%B0%D1%82%D0%B8%D1%87%D0%BD%D0%B0%D1%8F%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B0%D1%8F%20%"
		"D0%BA%D0%BE%D0%BB%D0%BE%D0%BD%D0%BA%D0%B0%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%22%7D%7D%2C%7B%22%D0%9F%D1%80%D0%BE%D1%81%D0%BC%D0%BE%D1%82%D1%80%20%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%B0%22%3A%7B%22%D0%9F%D0%BB%D0%B0%D1%88%D0%BA%D0%B0%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%BE%D0%B4%D1%87%D0%B8%D0%BA%D0%B0%22%3A%7B%222pane%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%22%7D%7D%7D%5D", 
		LAST);

	lr_end_transaction("check messages",LR_AUTO);

	lr_think_time(16);

	web_submit_data("models.jsx_19", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=message-in-reply-to-ng", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t208.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=_model.0", "Value=message-in-reply-to-ng", ENDITEM, 
		"Name=message_id.0", "Value=<1173041489149209@web26j.yandex.ru>", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149488478", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		EXTRARES, 
		"Url=https://yastatic.net/mail/_/6989570545cfefe15cafc8012c0a6de1.js", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/45b05eac4394e0c161b208537562b97b.css", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://yastatic.net/mail/_/8d023a2eb29b37548fec22ae4aeb8e5b.yate", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=/monitoring_liza.txt?uid=474076123&cid=u2709-1489149426954-81932979&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916593&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58&node=false&lifetime=60&allTime=1312&allSumTime=246&requestTime=1181&selfTime=131&full=1312&collectModels.0=2&requestModels.0=1181&collectModels.1=0&requestModels.1=0&collectViews=0&generateHTML="
		"2&html2node=1&triggerHideEvents=0&insertNodes=3&triggerEvents=122&showEditor=116&blockname=compose-message-editor-tiny&request=1181&event=BlockTimings&visibilityState=visible&show=1312&browser=MSIE&afterload=true", "Referer=https://mail.yandex.ru/", ENDITEM, 
		LAST);

	web_custom_request("40081755_5", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916593&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310153809%3Aet%3A1489149489%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A58%3Arn%3A49187922%3Ahid%3A242914354%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149489%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t209.inf", 
		"Body=site-info=%5B%7B%22Qui%D1%81k%20Reply%22%3A%7B%22%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%BE%20%D0%BD%D0%B0%20%D0%BE%D1%82%D0%B4%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9%20%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B5%22%3A%22%D0%9A%D0%BB%D0%B8%D0%BA%20%D0%BD%D0%B0%20%5C%22%D0%9E%D1%82%D0%B2%D0%B5%D1%82%D0%B8%D1%82%D1%8C%5C%22%22%7D%7D%5D", 
		LAST);

	lr_start_transaction("replay");

	web_custom_request("40081755_6", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916593&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310153810%3Aet%3A1489149491%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A59%3Arn%3A924062656%3Ahid%3A242914354%3Ads%3A%2C%2C%2C60900%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149491%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t210.inf", 
		"Body=site-info=%5B%7B%22Qui%D1%81k%20Reply%22%3A%7B%22%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%BE%20%D0%BD%D0%B0%20%D0%BE%D1%82%D0%B4%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9%20%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B5%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%22%7D%7D%5D", 
		LAST);

	lr_think_time(8);

	web_submit_data("do-send-json.jsx", 
		"Action=https://mail.yandex.ru/u2709/api/do-send-json.jsx?_save=true", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t211.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=att_ids", "Value=", ENDITEM, 
		"Name=bcc", "Value=", ENDITEM, 
		"Name=captcha_entered", "Value=", ENDITEM, 
		"Name=captcha_key", "Value=", ENDITEM, 
		"Name=cc", "Value=", ENDITEM, 
		"Name=charset", "Value=", ENDITEM, 
		"Name=compose_check", "Value=6e3ae5c2371db85f50d762c8b7406733", ENDITEM, 
		"Name=confirm_limit", "Value=", ENDITEM, 
		"Name=current_folder", "Value=", ENDITEM, 
		"Name=doit", "Value=", ENDITEM, 
		"Name=errors", "Value=[object Object]", ENDITEM, 
		"Name=fid", "Value=", ENDITEM, 
		"Name=from_mailbox", "Value=ufo.xco2017@yandex.ru", ENDITEM, 
		"Name=from_name", "Value=xcom ufo", ENDITEM, 
		"Name=get_abook", "Value=", ENDITEM, 
		"Name=html", "Value=", ENDITEM, 
		"Name=idcs", "Value=", ENDITEM, 
		"Name=ign_overwrite", "Value=yes", ENDITEM, 
		"Name=initial_cc", "Value=", ENDITEM, 
		"Name=initial_to", "Value=\"xcom ufo\" <ufo.xco2017@yandex.ru>", ENDITEM, 
		"Name=inreplyto", "Value=<1173041489149209@web26j.yandex.ru>", ENDITEM, 
		"Name=mark_as", "Value=replied", ENDITEM, 
		"Name=mark_ids", "Value=161566636631916593", ENDITEM, 
		"Name=narod_att", "Value=", ENDITEM, 
		"Name=nosave", "Value=", ENDITEM, 
		"Name=nosend", "Value=yes", ENDITEM, 
		"Name=notify_on_send", "Value=", ENDITEM, 
		"Name=overwrite", "Value=161566636631916593", ENDITEM, 
		"Name=parts", "Value=", ENDITEM, 
		"Name=phone", "Value=", ENDITEM, 
		"Name=references", "Value=<1173041489149209@web26j.yandex.ru>", ENDITEM, 
		"Name=remind_period", "Value=", ENDITEM, 
		"Name=recipients-diff", "Value=[object Object]", ENDITEM, 
		"Name=retpath", "Value=", ENDITEM, 
		"Name=returl", "Value=", ENDITEM, 
		"Name=saveDraft", "Value=", ENDITEM, 
		"Name=save_symbol", "Value=draft", ENDITEM, 
		"Name=send", "Value=<div>отвеееееееееееееет</div><div><br/></div><div><br/></div><div>10.03.2017, 15:33, &quot;xcom ufo&quot; &lt;ufo.xco2017@yandex.ru&gt;:</div><blockquote type=\"cite\"><p>ес<br /><br />10.03.2017, 13:01, \"xcom ufo\" &lt;<a href=\"mailto:ufo.xco2017@yandex.ru\">ufo.xco2017@yandex.ru</a>&gt;:<br /></p></blockquote>", ENDITEM, 
		"Name=send_time", "Value=", ENDITEM, 
		"Name=store_fid", "Value=", ENDITEM, 
		"Name=store_name", "Value=", ENDITEM, 
		"Name=strict_charset", "Value=", ENDITEM, 
		"Name=style", "Value=", ENDITEM, 
		"Name=subj", "Value=Re: test", ENDITEM, 
		"Name=to", "Value=\"xcom ufo\" <ufo.xco2017@yandex.ru>", ENDITEM, 
		"Name=ttype", "Value=html", ENDITEM, 
		"Name=where", "Value=", ENDITEM, 
		"Name=from", "Value=[object Object]", ENDITEM, 
		"Name=collapsedMessage", "Value=true", ENDITEM, 
		"Name=handler.do-send", "Value=1", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149499792", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_20", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=folders,labels", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t212.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=folders", ENDITEM, 
		"Name=_model.1", "Value=labels", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149500042", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("do-send-json.jsx_2", 
		"Action=https://mail.yandex.ru/u2709/api/do-send-json.jsx?_send=true", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t213.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=att_ids", "Value=", ENDITEM, 
		"Name=bcc", "Value=", ENDITEM, 
		"Name=captcha_entered", "Value=", ENDITEM, 
		"Name=captcha_key", "Value=", ENDITEM, 
		"Name=cc", "Value=", ENDITEM, 
		"Name=charset", "Value=", ENDITEM, 
		"Name=compose_check", "Value=6e3ae5c2371db85f50d762c8b7406733", ENDITEM, 
		"Name=confirm_limit", "Value=", ENDITEM, 
		"Name=current_folder", "Value=6", ENDITEM, 
		"Name=doit", "Value=", ENDITEM, 
		"Name=errors", "Value=[object Object]", ENDITEM, 
		"Name=fid", "Value=", ENDITEM, 
		"Name=from_mailbox", "Value=ufo.xco2017@yandex.ru", ENDITEM, 
		"Name=from_name", "Value=xcom ufo", ENDITEM, 
		"Name=get_abook", "Value=", ENDITEM, 
		"Name=html", "Value=", ENDITEM, 
		"Name=idcs", "Value=", ENDITEM, 
		"Name=ign_overwrite", "Value=no", ENDITEM, 
		"Name=initial_cc", "Value=", ENDITEM, 
		"Name=initial_to", "Value=\"xcom ufo\" <ufo.xco2017@yandex.ru>", ENDITEM, 
		"Name=inreplyto", "Value=<1173041489149209@web26j.yandex.ru>", ENDITEM, 
		"Name=mark_as", "Value=replied", ENDITEM, 
		"Name=mark_ids", "Value=161566636631916593", ENDITEM, 
		"Name=narod_att", "Value=", ENDITEM, 
		"Name=nosave", "Value=", ENDITEM, 
		"Name=nosend", "Value=", ENDITEM, 
		"Name=notify_on_send", "Value=", ENDITEM, 
		"Name=overwrite", "Value=161566636631916594", ENDITEM, 
		"Name=parts", "Value=", ENDITEM, 
		"Name=phone", "Value=", ENDITEM, 
		"Name=references", "Value=<1173041489149209@web26j.yandex.ru>", ENDITEM, 
		"Name=remind_period", "Value=", ENDITEM, 
		"Name=recipients-diff", "Value=[object Object]", ENDITEM, 
		"Name=retpath", "Value=", ENDITEM, 
		"Name=returl", "Value=", ENDITEM, 
		"Name=saveDraft", "Value=", ENDITEM, 
		"Name=save_symbol", "Value=draft", ENDITEM, 
		"Name=send", "Value=<div>отвееееееееееееееттттт</div><div><br/></div><div><br/></div><div>10.03.2017, 15:33, &quot;xcom ufo&quot; &lt;ufo.xco2017@yandex.ru&gt;:</div><blockquote type=\"cite\"><p>ес<br /><br />10.03.2017, 13:01, \"xcom ufo\" &lt;<a href=\"mailto:ufo.xco2017@yandex.ru\">ufo.xco2017@yandex.ru</a>&gt;:<br /></p></blockquote>", ENDITEM, 
		"Name=send_time", "Value=", ENDITEM, 
		"Name=store_fid", "Value=", ENDITEM, 
		"Name=store_name", "Value=", ENDITEM, 
		"Name=strict_charset", "Value=", ENDITEM, 
		"Name=style", "Value=", ENDITEM, 
		"Name=subj", "Value=Re: test", ENDITEM, 
		"Name=to", "Value=\"xcom ufo\" <ufo.xco2017@yandex.ru>", ENDITEM, 
		"Name=ttype", "Value=html", ENDITEM, 
		"Name=where", "Value=", ENDITEM, 
		"Name=from", "Value=[object Object]", ENDITEM, 
		"Name=collapsedMessage", "Value=true", ENDITEM, 
		"Name=handler.do-send", "Value=1", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149501734", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("40081755_7", 
		"Action=https://mc.yandex.ru/watch/40081755?page-ref=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916593&page-url=goal%3A%2F%2Fmail.yandex.ru%2FSEND&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1519x745%3Az%3A180%3Ai%3A20170310153822%3Aet%3A1489149502%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Als%3A1153974744958%3Arqn%3A60%3Arn%3A99550131%3Ahid%3A242914354%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149502%3Au%3A1488658405454999924%3At%3A%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%BE%20%C2%ABRe%3A%20test%C2%BB%20%E2%80%94%20xcom%20ufo%20%E2%80%94%20%D0%AF%D0"
		"%BD%D0%B4%D0%B5%D0%BA%D1%81.%D0%9F%D0%BE%D1%87%D1%82%D0%B0", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t214.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("models.jsx_21", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=folders,labels", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t215.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=folders", ENDITEM, 
		"Name=_model.1", "Value=labels", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=zT50ZT4Ncb91X3pAOSrSrhI+Z3heuERa", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149426954-81932979", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149502173", ENDITEM, 
		"Name=_exp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_custom_request("40081755_8", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916593&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310153822%3Aet%3A1489149503%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A61%3Arn%3A524015348%3Ahid%3A242914354%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149503%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t216.inf", 
		"Body=site-info=%5B%7B%22%D0%9E%D1%82%D0%BF%D1%80%D0%B0%D0%B2%D0%BA%D0%B0%20%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%B0%22%3A%22QR%22%7D%2C%7B%22Qui%D1%81k%20Reply%22%3A%7B%22%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%BE%20%D0%BD%D0%B0%20%D0%BE%D1%82%D0%B4%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9%20%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B5%22%3A%22%D0%9A%D0%BB%D0%B8%D0%BA%20%D0%BD%D0%B0%20%5C%22%D0%9E%D1%82%D0%BF%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%8C%5C%22%22%7D%7D%5D", 
		LAST);

	lr_end_transaction("replay",LR_AUTO);

	lr_start_transaction("check after replay");

	web_add_cookie("yandexuid=1323753751488658402; DOMAIN=clck.yandex.ru");

	web_add_cookie("i=9watCZ0XndZ9hI+MrL2gQmQkLUJywAC+B5aUe+iWdudktzdxuU4qK7ZNkxGsKlZxvKPmmudu+V+Ei9RoDPcxI3SXk0w=; DOMAIN=clck.yandex.ru");

	web_add_cookie("_ym_uid=1488658405454999924; DOMAIN=clck.yandex.ru");

	web_add_cookie("_ym_isad=2; DOMAIN=clck.yandex.ru");

	web_add_cookie("fuid01=58bb1fe43f1985ca.mchv1kTx9TEts0-0Gp_WmXaQDv9YzfRxHMjAhTjj3FWSUQEJC61ZkwpNsdz8bUlcpKF_3mbcsWNVPeDp-t2gp4jJPGbGmhsyD7VuFZi-GicCHCUYXGlhUGmo6Ch_ljdX; DOMAIN=clck.yandex.ru");

	web_add_cookie("yandex_gid=213; DOMAIN=clck.yandex.ru");

	web_add_cookie("_ym_visorc_784657=w; DOMAIN=clck.yandex.ru");

	lr_think_time(21);

	web_submit_data("40081755_9", 
		"Action=https://mc.yandex.ru/watch/40081755?page-ref=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916593&page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1519x745%3Az%3A180%3Ai%3A20170310153851%3Aet%3A1489149532%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Apv%3A1%3Als%3A1153974744958%3Arqn%3A62%3Arn%3A393225873%3Ahid%3A242914354%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149532%3Au%3A1488658405454999924%3At%3A%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%BE%20%C2%ABRe%3A%20test%C2%BB%20%E2%80%94%20xcom%20ufo%20%E2%80%94%20%D0%AF%D"
		"0%BD%D0%B4%D0%B5%D0%BA%D1%81.%D0%9F%D0%BE%D1%87%D1%82%D0%B0", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t217.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		EXTRARES, 
		"Url=https://mail.yandex.ru/monitoring_liza.txt?uid=474076123&cid=u2709-1489149426954-81932979&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=36377,0,91;40287,0,46;38717,0,84;34595,0,54;31190,0,58&node=false&lifetime=102&allTime=67&allSumTime=65&requestTime=0&selfTime=67&full=67&collectModels.0=5&requestModels.0=0&collectViews=3&generateHTML=5&html2node=2&triggerHideEvents=27&insertNodes="
		"21&triggerEvents=2&blockname=messages&request=0&event=BlockTimings&visibilityState=visible&show=67&browser=MSIE&afterload=true", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://clck.yandex.ru/click/dtype=stred/pid=2/cid=71105/path=msg.click.cancel/rnd=1489149661619/*https://mail.yandex.ru/?ncrnd=1213&uid=474076123&login=ufo-xco2017", "Referer=https://mail.yandex.ru/", ENDITEM, 
		LAST);

	web_custom_request("40081755_10", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310153852%3Aet%3A1489149533%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A63%3Arn%3A1059421778%3Ahid%3A242914354%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149533%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t218.inf", 
		"Body=site-info=%5B%7B%22%D0%9B%D0%B5%D0%B2%D0%B0%D1%8F%20%D0%BA%D0%BE%D0%BB%D0%BE%D0%BD%D0%BA%D0%B0%22%3A%7B%222pane%22%3A%7B%22%D0%A1%D0%BF%D0%B8%D1%81%D0%BE%D0%BA%20%D0%BF%D0%B0%D0%BF%D0%BE%D0%BA%22%3A%7B%22%D0%A2%D0%B5%D0%BA%D1%83%D1%89%D0%B0%D1%8F%20%D0%BF%D0%B0%D0%BF%D0%BA%D0%B0%20%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8F%22%3A%22%D0%9A%D0%BB%D0%B8%D0%BA%22%7D%7D%7D%7D%5D", 
		LAST);

	lr_think_time(5);

	web_submit_data("40081755_61", 
		"Action=https://mc.yandex.ru/watch/40081755?page-ref=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox%3FshowDatePager%3Dyes&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1519x745%3Az%3A180%3Ai%3A20170310154223%3Aet%3A1489149744%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Apv%3A1%3Als%3A1153974744958%3Arqn%3A114%3Arn%3A217438101%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149744%3Au%3A1488658405454999924%3At%3A2%20%C2%B7%20%D0%92%D1%85%D0%BE%D0%B4%D1%8F%D1%89%D0%B8%D0%B5%20%E2%80%94%20%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%"
		"81.%D0%9F%D0%BE%D1%87%D1%82%D0%B0", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t417.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_custom_request("40081755_62", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox%3FshowDatePager%3Dyes&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310154224%3Aet%3A1489149745%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A115%3Arn%3A98747137%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149745%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t418.inf", 
		"Body=site-info=%5B%7B%22%D0%9B%D0%B5%D0%B2%D0%B0%D1%8F%20%D0%BA%D0%BE%D0%BB%D0%BE%D0%BD%D0%BA%D0%B0%22%3A%7B%222pane%22%3A%7B%22%D0%A1%D0%BF%D0%B8%D1%81%D0%BE%D0%BA%20%D0%BF%D0%B0%D0%BF%D0%BE%D0%BA%22%3A%7B%22%D0%A2%D0%B5%D0%BA%D1%83%D1%89%D0%B0%D1%8F%20%D0%BF%D0%B0%D0%BF%D0%BA%D0%B0%20%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8F%22%3A%22%D0%9A%D0%BB%D0%B8%D0%BA%22%7D%7D%7D%7D%5D", 
		LAST);

	lr_think_time(6);

	web_submit_data("models.jsx_81", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=messages", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t419.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=messages", ENDITEM, 
		"Name=thread_id.0", "Value=t161566636631916603", ENDITEM, 
		"Name=sort_type.0", "Value=date", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149751448", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		EXTRARES, 
		"Url=/monitoring_liza.txt?uid=474076123&cid=u2709-1489149733595-43618213&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox%3FshowDatePager%3Dyes&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=34595,0,54;31190,0,58&node=false&lifetime=17&type=mark_read_from_list&mids=161566636631916604&afterload=true", "Referer=https://mail.yandex.ru/", ENDITEM, 
		LAST);

	web_custom_request("40081755_63", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox%3FshowDatePager%3Dyes&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310154232%3Aet%3A1489149752%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A116%3Arn%3A736912026%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149752%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t420.inf", 
		"Body=site-info=%5B%7B%22%D0%A2%D1%80%D0%B5%D0%B4%D1%8B%22%3A%22%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D0%B8%D0%B5%20%D1%82%D1%80%D0%B5%D0%B4%D0%B0%20%D0%B8%D0%B7%20%D1%81%D0%BF%D0%B8%D1%81%D0%BA%D0%B0%20%D0%BF%D0%B8%D1%81%D0%B5%D0%BC%22%7D%5D", 
		LAST);

	web_submit_data("models.jsx_82", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=do-messages", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t421.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=do-messages", ENDITEM, 
		"Name=ids.0", "Value=161566636631916604", ENDITEM, 
		"Name=action.0", "Value=mark", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149753416", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_custom_request("40081755_64", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox%3FshowDatePager%3Dyes&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310154234%3Aet%3A1489149754%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A117%3Arn%3A982376715%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149754%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t422.inf", 
		"Body=site-info=%5B%7B%22Toolbar%20%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%B0%22%3A%7B%22%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%BE%22%3A%7B%22%D0%BE%D1%82%D0%BC%D0%B5%D1%82%D0%B8%D1%82%D1%8C%20%D0%BA%D0%B0%D0%BA%20%D0%BF%D1%80%D0%BE%D1%87%D0%B8%D1%82%D0%B0%D0%BD%D0%BD%D0%BE%D0%B5%22%3A%22%D0%BA%D0%BB%D0%B8%D0%BA%22%7D%7D%7D%5D", 
		LAST);

	web_submit_data("models.jsx_83", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=do-messages", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t423.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=do-messages", ENDITEM, 
		"Name=ids.0", "Value=161566636631916604", ENDITEM, 
		"Name=action.0", "Value=unmark", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149756142", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_custom_request("40081755_65", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox%3FshowDatePager%3Dyes&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310154237%3Aet%3A1489149757%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A118%3Arn%3A751134418%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149757%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t424.inf", 
		"Body=site-info="
		"%5B%7B%22Toolbar%20%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%B0%22%3A%7B%22%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%BE%22%3A%7B%22%D0%BE%D1%82%D0%BC%D0%B5%D1%82%D0%B8%D1%82%D1%8C%20%D0%BA%D0%B0%D0%BA%20%D0%BD%D0%B5%D0%BF%D1%80%D0%BE%D1%87%D0%B8%D1%82%D0%B0%D0%BD%D0%BD%D0%BE%D0%B5%22%3A%22%D0%BA%D0%BB%D0%B8%D0%BA%22%7D%7D%7D%2C%7B%22%D0%A2%D1%80%D0%B5%D0%B4%D1%8B%22%3A%22%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D0%B8%D0%B5%20%D1%82%D1%80%D0%B5%D0%B4%D0%B0%20%D0%B8%D0%B7%20%D1%81%D0%BF%D0%B8%D1%81%D0%BA%D0%B0%20%D0%BF"
		"%D0%B8%D1%81%D0%B5%D0%BC%22%7D%5D", 
		LAST);

	web_url("001001.htm_2", 
		"URL=https://awaps.yandex.ru/0/9947/001001.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t425.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("models.jsx_84", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=messages", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t426.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=messages", ENDITEM, 
		"Name=thread_id.0", "Value=t161566636631916599", ENDITEM, 
		"Name=sort_type.0", "Value=date", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149758610", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_custom_request("40081755_66", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox%3FshowDatePager%3Dyes&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310154239%3Aet%3A1489149760%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A119%3Arn%3A528105793%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149760%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t427.inf", 
		"Body=site-info=%5B%7B%22%D0%A2%D1%80%D0%B5%D0%B4%D1%8B%22%3A%22%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D0%B8%D0%B5%20%D1%82%D1%80%D0%B5%D0%B4%D0%B0%20%D0%B8%D0%B7%20%D1%81%D0%BF%D0%B8%D1%81%D0%BA%D0%B0%20%D0%BF%D0%B8%D1%81%D0%B5%D0%BC%22%7D%5D", 
		LAST);

	web_submit_data("40081755_67", 
		"Action=https://mc.yandex.ru/watch/40081755?page-ref=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox%3FshowDatePager%3Dyes&page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916600&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1519x745%3Az%3A180%3Ai%3A20170310154239%3Aet%3A1489149760%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Apv%3A1%3Als%3A1153974744958%3Arqn%3A120%3Arn%3A556021556%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149760%3Au%3A1488658405454999924%3At%3A2%20%C2%B7%20%D0%92%D1%85%D0%BE%D0%B4%D1%8F%D1%89%D0%B8%D0%B5%20%E2%80%94%20%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%"
		"81.%D0%9F%D0%BE%D1%87%D1%82%D0%B0", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t428.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("models.jsx_85", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=message-body,message-nearest", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t429.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=message-body", ENDITEM, 
		"Name=ids.0", "Value=161566636631916600", ENDITEM, 
		"Name=is_spam.0", "Value=false", ENDITEM, 
		"Name=raw.0", "Value=false", ENDITEM, 
		"Name=draft.0", "Value=false", ENDITEM, 
		"Name=_model.1", "Value=message-nearest", ENDITEM, 
		"Name=ids.1", "Value=161566636631916600", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149759764", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("action-log.jsx_5", 
		"Action=https://mail.yandex.ru/u2709/api/action-log.jsx", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t430.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=data", "Value={\"timestamp\":1489138959990,\"action\":\"show\",\"platform\":\"Win32\",\"filter\":{\"page\":\"message\",\"type\":null,\"param\":null},\"message\":{\"thread\":0,\"timestamp\":1489149634000,\"type\":[4,54],\"from\":\"ufo.xco2017@yandex.ru\",\"index\":1,\"subject\":\"tessssssssssssttttttttttttttttttt\",\"folder\":{\"fid\":\"1\",\"symbol\":\"inbox\"},\"mid\":\"161566636631916600\"}}", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149759990", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_86", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=do-journal-log", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t431.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=do-journal-log", ENDITEM, 
		"Name=params.0", "Value={\"operation\":\"startReading\",\"target\":\"message\",\"isSearch\":false,\"readingId\":\"13237537514886584020cc5c7cae919f\",\"mid\":\"161566636631916600\"}", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149759994", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_87", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=do-messages", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t432.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=do-messages", ENDITEM, 
		"Name=ids.0", "Value=161566636631916600", ENDITEM, 
		"Name=action.0", "Value=mark", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149759981", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_88", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=email-info", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t433.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=_model.0", "Value=email-info", ENDITEM, 
		"Name=email.0", "Value=ufo.xco2017@yandex.ru", ENDITEM, 
		"Name=ref.0", "Value=6614159eec6fa7af7b4f667514d7a2c3", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149760028", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		EXTRARES, 
		"Url=/monitoring_liza.txt?uid=474076123&cid=u2709-1489149733595-43618213&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916600&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=34595,0,54;31190,0,58&node=false&lifetime=24&allTime=73&allSumTime=48&requestTime=0&selfTime=73&full=73&collectModels.0=3&requestModels.0=0&collectViews=1&generateHTML=4&html2node=1&triggerHideEvents=1&insertNodes=11&triggerEvents=27&blockname="
		"message-body&request=0&event=BlockTimings&visibilityState=visible&show=73&browser=MSIE&afterload=true", "Referer=https://mail.yandex.ru/", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_89", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=abook-contacts", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t434.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=_model.0", "Value=abook-contacts", ENDITEM, 
		"Name=emails.0", "Value=ufo.xco2017@yandex.ru", ENDITEM, 
		"Name=pagesize.0", "Value=30", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149760121", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_custom_request("40081755_68", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916600&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310154241%3Aet%3A1489149761%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A121%3Arn%3A126312637%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149761%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t435.inf", 
		"Body=site-info="
		"%5B%7B%22%D0%9F%D1%80%D0%BE%D1%81%D0%BC%D0%BE%D1%82%D1%80%20%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%B0%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%20%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%B0%20%D0%BD%D0%B0%20%D0%BE%D1%82%D0%B4%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9%20%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B5%22%7D%2C%7B%22%D0%9F%D1%80%D0%B0%D0%B2%D0%B0%D1%8F%20%D0%BA%D0%BE%D0%BB%D0%BE%D0%BD%D0%BA%D0%B0%22%3A%7B%22%D0%A1%D1%82%D0%B0%D1%82%D0%B8%D1%87%D0%BD%D0%B0%D1%8F%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B0%D1%8F%20%"
		"D0%BA%D0%BE%D0%BB%D0%BE%D0%BD%D0%BA%D0%B0%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%22%7D%7D%5D", 
		LAST);

	lr_end_transaction("check after replay",LR_AUTO);

	web_submit_data("40081755_69", 
		"Action=https://mc.yandex.ru/watch/40081755?page-ref=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916600&page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1519x745%3Az%3A180%3Ai%3A20170310154244%3Aet%3A1489149765%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Apv%3A1%3Als%3A1153974744958%3Arqn%3A122%3Arn%3A599750165%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149765%3Au%3A1488658405454999924%3At%3A%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%BE%20%C2%ABtessssssssssssttttttttttttttttttt%C2%BB%20%E2%80%94%20xcom%20ufo%"
		"20%E2%80%94%20%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81.%D0%9F%D0%BE%D1%87%D1%82%D0%B0", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t436.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		EXTRARES, 
		"Url=https://mail.yandex.ru/monitoring_liza.txt?uid=474076123&cid=u2709-1489149733595-43618213&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=34595,0,54;31190,0,58&node=false&lifetime=28&allTime=69&allSumTime=63&requestTime=1&selfTime=68&full=69&collectModels.0=6&requestModels.0=1&collectViews=1&generateHTML=5&html2node=5&triggerHideEvents=23&insertNodes=20&triggerEvents=3&blockname="
		"messages&request=1&event=BlockTimings&visibilityState=visible&show=69&browser=MSIE&afterload=true", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://clck.yandex.ru/click/dtype=stred/pid=2/cid=71105/path=msg.click.cancel/rnd=1489150455902/*https://mail.yandex.ru/?ncrnd=1213&uid=474076123&login=ufo-xco2017", "Referer=https://mail.yandex.ru/", ENDITEM, 
		LAST);

	web_custom_request("40081755_70", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310154245%3Aet%3A1489149766%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A123%3Arn%3A317367487%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149766%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t437.inf", 
		"Body=site-info=%5B%7B%22%D0%9B%D0%B5%D0%B2%D0%B0%D1%8F%20%D0%BA%D0%BE%D0%BB%D0%BE%D0%BD%D0%BA%D0%B0%22%3A%7B%222pane%22%3A%7B%22%D0%A1%D0%BF%D0%B8%D1%81%D0%BE%D0%BA%20%D0%BF%D0%B0%D0%BF%D0%BE%D0%BA%22%3A%7B%22%D0%A2%D0%B5%D0%BA%D1%83%D1%89%D0%B0%D1%8F%20%D0%BF%D0%B0%D0%BF%D0%BA%D0%B0%20%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8F%22%3A%22%D0%9A%D0%BB%D0%B8%D0%BA%22%7D%7D%7D%7D%5D", 
		LAST);

	web_custom_request("40081755_71", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310154248%3Aet%3A1489149769%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A124%3Arn%3A912665773%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149769%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t438.inf", 
		"Body=site-info=%5B%7B%22%D0%A2%D1%80%D0%B5%D0%B4%D1%8B%22%3A%22%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D0%B8%D0%B5%20%D1%82%D1%80%D0%B5%D0%B4%D0%B0%20%D0%B8%D0%B7%20%D1%81%D0%BF%D0%B8%D1%81%D0%BA%D0%B0%20%D0%BF%D0%B8%D1%81%D0%B5%D0%BC%22%7D%2C%7B%22%D0%A2%D1%80%D0%B5%D0%B4%D1%8B%22%3A%22%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D0%B8%D0%B5%20%D1%82%D1%80%D0%B5%D0%B4%D0%B0%20%D0%B8%D0%B7%20%D1%81%D0%BF%D0%B8%D1%81%D0%BA%D0%B0%20%D0%BF%D0%B8%D1%81%D0%B5%D0%BC%22%7D%5D", 
		LAST);

	web_custom_request("40081755_72", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310154250%3Aet%3A1489149771%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A125%3Arn%3A30357999%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149771%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t439.inf", 
		"Body=site-info=%5B%7B%22%D0%A2%D1%80%D0%B5%D0%B4%D1%8B%22%3A%22%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D0%B8%D0%B5%20%D1%82%D1%80%D0%B5%D0%B4%D0%B0%20%D0%B8%D0%B7%20%D1%81%D0%BF%D0%B8%D1%81%D0%BA%D0%B0%20%D0%BF%D0%B8%D1%81%D0%B5%D0%BC%22%7D%5D", 
		LAST);

	web_custom_request("40081755_73", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310154252%3Aet%3A1489149772%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A126%3Arn%3A323103976%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149772%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t440.inf", 
		"Body=site-info=%5B%7B%22%D0%A2%D1%80%D0%B5%D0%B4%D1%8B%22%3A%22%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D0%B8%D0%B5%20%D1%82%D1%80%D0%B5%D0%B4%D0%B0%20%D0%B8%D0%B7%20%D1%81%D0%BF%D0%B8%D1%81%D0%BA%D0%B0%20%D0%BF%D0%B8%D1%81%D0%B5%D0%BC%22%7D%2C%7B%22%D0%A2%D1%80%D0%B5%D0%B4%D1%8B%22%3A%22%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D0%B8%D0%B5%20%D1%82%D1%80%D0%B5%D0%B4%D0%B0%20%D0%B8%D0%B7%20%D1%81%D0%BF%D0%B8%D1%81%D0%BA%D0%B0%20%D0%BF%D0%B8%D1%81%D0%B5%D0%BC%22%7D%5D", 
		LAST);

	web_submit_data("40081755_74", 
		"Action=https://mc.yandex.ru/watch/40081755?page-ref=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23search%3Fscope%3Dhdr_from%26request%3Dufo.xco2017%2540yandex.ru&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1519x745%3Az%3A180%3Ai%3A20170310154253%3Aet%3A1489149773%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Apv%3A1%3Als%3A1153974744958%3Arqn%3A127%3Arn%3A585000852%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149773%3Au%3A1488658405454999924%3At%3A1%20%C2%B7%20%D0%92%D1%85%D0%BE%D0%B4%D1%8F%D1%89%D0%B8%D0%B5%20%E2%80%94%20%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%"
		"81.%D0%9F%D0%BE%D1%87%D1%82%D0%B0", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t441.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("models.jsx_90", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=messages", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t442.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=_model.0", "Value=messages", ENDITEM, 
		"Name=sort_type.0", "Value=date", ENDITEM, 
		"Name=request.0", "Value=ufo.xco2017@yandex.ru", ENDITEM, 
		"Name=scope.0", "Value=hdr_from", ENDITEM, 
		"Name=search.0", "Value=search", ENDITEM, 
		"Name=reqid.0", "Value=1489149773370474076123", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149773370", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		EXTRARES, 
		"Url=/monitoring_liza.txt?uid=474076123&cid=u2709-1489149733595-43618213&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23search%3Fscope%3Dhdr_from%26request%3Dufo.xco2017%2540yandex.ru&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=34595,0,54;31190,0,58&node=false&lifetime=37&allTime=577&allSumTime=135&requestTime=440&selfTime=137&full=577&collectModels.0=6&requestModels.0=440&collectModels.1=16&requestModels.1=0&collectViews=1&generateHTML="
		"40&html2node=28&triggerHideEvents=2&insertNodes=31&triggerEvents=11&blockname=messages&request=440&event=BlockTimings&visibilityState=visible&show=577&browser=MSIE&afterload=true", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://clck.yandex.ru/click/dtype=PS/r=ufo.xco2017%40yandex.ru/pos=1/project=search_mail/product=WEB/reqid=1489149773370474076123/user=474076123/mid=161566636631916604/time=1405/clicktype=mail/filter=scope:hdr_from/exp=34595,31190/*https://mail.yandex.ru/?ncrnd=1213&uid=474076123&login=ufo-xco2017", "Referer=https://mail.yandex.ru/", ENDITEM, 
		LAST);

	web_submit_data("40081755_75", 
		"Action=https://mc.yandex.ru/watch/40081755?page-ref=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23search%3Fscope%3Dhdr_from%26request%3Dufo.xco2017%2540yandex.ru&page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916604&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1519x745%3Az%3A180%3Ai%3A20170310154255%3Aet%3A1489149775%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Apv%3A1%3Als%3A1153974744958%3Arqn%3A128%3Arn%3A942293560%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149775%3Au%3A1488658405454999924%3At%3A%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81.%D0%9F%D0%BE%D1%87%D1%82%D0%B0", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t443.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("models.jsx_91", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=message-body,message-nearest", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t444.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=message-body", ENDITEM, 
		"Name=ids.0", "Value=161566636631916604", ENDITEM, 
		"Name=is_spam.0", "Value=false", ENDITEM, 
		"Name=raw.0", "Value=false", ENDITEM, 
		"Name=draft.0", "Value=false", ENDITEM, 
		"Name=_model.1", "Value=message-nearest", ENDITEM, 
		"Name=ids.1", "Value=161566636631916604", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149775366", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("action-log.jsx_6", 
		"Action=https://mail.yandex.ru/u2709/api/action-log.jsx", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t445.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=data", "Value={\"timestamp\":1489138975577,\"action\":\"show\",\"platform\":\"Win32\",\"filter\":{\"page\":\"message\",\"type\":\"search\",\"param\":\"request=ufo.xco2017%40yandex.ru&scope=hdr_from&reqid=1489149773370474076123\"},\"message\":{\"thread\":0,\"timestamp\":1489149716000,\"type\":[4,54],\"from\":\"ufo.xco2017@yandex.ru\",\"index\":1,\"subject\":\"ttttttteeeeeeeeeeeeeeeeeeeeesssssssssssssssssssssstttttttttttttttttttttt\",\"folder\":{\"fid\":\"1\",\"symbol\":\"inbox\"},\"mid\":\""
		"161566636631916604\"}}", ENDITEM, 
		"Name=isSearch", "Value=true", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149775577", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_92", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=do-journal-log", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t446.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=do-journal-log", ENDITEM, 
		"Name=params.0", "Value={\"operation\":\"startReading\",\"target\":\"message\",\"isSearch\":false,\"readingId\":\"1323753751488658402367ff40cae8178\",\"mid\":\"161566636631916604\"}", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149775579", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		LAST);

	web_submit_data("models.jsx_93", 
		"Action=https://mail.yandex.ru/u2709/api/models.jsx?_m=do-messages", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t447.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_model.0", "Value=do-messages", ENDITEM, 
		"Name=ids.0", "Value=161566636631916604", ENDITEM, 
		"Name=action.0", "Value=mark", ENDITEM, 
		"Name=_uid", "Value=474076123", ENDITEM, 
		"Name=_ckey", "Value=vqcL5qNdKYv0HuIdrmbu6H0thbE1qdLy", ENDITEM, 
		"Name=_connection_id", "Value=u2709-1489149733595-43618213", ENDITEM, 
		"Name=_locale", "Value=ru", ENDITEM, 
		"Name=_product", "Value=RUS", ENDITEM, 
		"Name=_timestamp", "Value=1489149775571", ENDITEM, 
		"Name=_exp", "Value=34595,0,54;31190,0,58;32334,0,88", ENDITEM, 
		"Name=_eexp", "Value=34595,0,54;31190,0,58", ENDITEM, 
		"Name=_messages_per_page", "Value=30", ENDITEM, 
		EXTRARES, 
		"Url=/monitoring_liza.txt?uid=474076123&cid=u2709-1489149733595-43618213&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916604&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=34595,0,54;31190,0,58&node=false&lifetime=39&allTime=44&allSumTime=33&requestTime=0&selfTime=44&full=44&collectModels.0=2&requestModels.0=0&collectViews=1&generateHTML=2&html2node=1&triggerHideEvents=0&insertNodes=14&triggerEvents=13&blockname="
		"message-body&request=0&event=BlockTimings&visibilityState=visible&show=44&browser=MSIE&afterload=true", "Referer=https://mail.yandex.ru/", ENDITEM, 
		LAST);

	web_add_cookie("display-culture=en-US; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20170304; DOMAIN=c.urs.microsoft.com");

	web_submit_data("40081755_76", 
		"Action=https://mc.yandex.ru/watch/40081755?page-ref=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23message%2F161566636631916604&page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Aw%3A1519x745%3Az%3A180%3Ai%3A20170310154256%3Aet%3A1489149777%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Apv%3A1%3Als%3A1153974744958%3Arqn%3A129%3Arn%3A545148659%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149777%3Au%3A1488658405454999924%3At%3A%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%BE%20%C2%ABttttttteeeeeeeeeeeeeeeeeeeeessssssssssssssssssssssttttttttttttttt"
		"ttttttt%C2%BB%20%E2%80%94%20xcom%20ufo%20%E2%80%94%20%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81.%D0%9F%D0%BE%D1%87%D1%82%D0%B0", 
		"Method=POST", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t448.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		EXTRARES, 
		"Url=https://clck.yandex.ru/click/dtype=stred/pid=2/cid=71105/path=msg.click.cancel/rnd=1489150601006/*https://mail.yandex.ru/?ncrnd=1213&uid=474076123&login=ufo-xco2017", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://mail.yandex.ru/monitoring_liza.txt?uid=474076123&cid=u2709-1489149733595-43618213&login=ufo-xco2017&loc=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&cv=jane-12.10.51-&lcl=ru&cdn=default&exp=34595,0,54;31190,0,58&node=false&lifetime=40&allTime=66&allSumTime=61&requestTime=0&selfTime=66&full=66&collectModels.0=5&requestModels.0=0&collectViews=1&generateHTML=7&html2node=5&triggerHideEvents=17&insertNodes=24&triggerEvents=2&blockname="
		"messages&request=0&event=BlockTimings&visibilityState=visible&show=66&browser=MSIE&afterload=true", "Referer=https://mail.yandex.ru/", ENDITEM, 
		"Url=https://c.urs.microsoft.com/l1.dat?cw=636247391644218467&v=3&cv=9.11.14393.0&os=10.0.14393.0.0&pg=4A72F430-B40C-4D36-A068-CE33ADA5ADF9", "Referer=", ENDITEM, 
		LAST);

	web_custom_request("40081755_77", 
		"URL=https://mc.yandex.ru/watch/40081755?page-url=https%3A%2F%2Fmail.yandex.ru%2F%3Fncrnd%3D1213%26uid%3D474076123%26login%3Dufo-xco2017%23inbox&ut=noindex&browser-info="
		"j%3A1%3As%3A1536x864x24%3Ask%3A1.25%3Aadb%3A2%3Af%3A24.0.0.221%3Afpr%3A331856404701%3Acn%3A1%3Az%3A180%3Ai%3A20170310154256%3Aet%3A1489149777%3Aen%3Autf-8%3Av%3A785%3Ac%3A1%3Ala%3Aru-ru%3Awh%3A1%3Aar%3A1%3Apa%3A1%3Als%3A1153974744958%3Arqn%3A130%3Arn%3A126477366%3Ahid%3A640240676%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%2C%3Arqnl%3A1%3Ast%3A1489149777%3Au%3A1488658405454999924", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t449.inf", 
		"Body=site-info="
		"%5B%7B%22%D0%9F%D1%80%D0%BE%D1%81%D0%BC%D0%BE%D1%82%D1%80%20%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%B0%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%20%D0%9F%D0%B8%D1%81%D1%8C%D0%BC%D0%B0%20%D0%BD%D0%B0%20%D0%BE%D1%82%D0%B4%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9%20%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B5%22%7D%2C%7B%22%D0%9F%D1%80%D0%B0%D0%B2%D0%B0%D1%8F%20%D0%BA%D0%BE%D0%BB%D0%BE%D0%BD%D0%BA%D0%B0%22%3A%7B%22%D0%A1%D1%82%D0%B0%D1%82%D0%B8%D1%87%D0%BD%D0%B0%D1%8F%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B0%D1%8F%20%"
		"D0%BA%D0%BE%D0%BB%D0%BE%D0%BD%D0%BA%D0%B0%22%3A%22%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%22%7D%7D%2C%7B%22%D0%9B%D0%B5%D0%B2%D0%B0%D1%8F%20%D0%BA%D0%BE%D0%BB%D0%BE%D0%BD%D0%BA%D0%B0%22%3A%7B%222pane%22%3A%7B%22%D0%A1%D0%BF%D0%B8%D1%81%D0%BE%D0%BA%20%D0%BF%D0%B0%D0%BF%D0%BE%D0%BA%22%3A%7B%22%D0%A2%D0%B5%D0%BA%D1%83%D1%89%D0%B0%D1%8F%20%D0%BF%D0%B0%D0%BF%D0%BA%D0%B0%20%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8F%22%3A%22%D0%9A%D0%BB%D0%B8%D0%BA%22%7D%7D%7D%7D%5D", 
		LAST);

	return 0;
}